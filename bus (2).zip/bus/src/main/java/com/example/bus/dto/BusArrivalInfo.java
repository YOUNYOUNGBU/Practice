// src/main/java/com/example/busapp/dto/BusArrivalInfo.java
package com.example.bus.dto; // ⭐️ 패키지 수정됨

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BusArrivalInfo {
    private String routeId;
    private String routeName;

    private Integer predictTime; // ⭐️ 추가/수정: 공공 API 원본 (예: 초 단위 또는 분 단위)
    private String arrivalInfo;  // ⭐️ 수정: "N분 후" 형식으로 가공된 데이터

    private String plateNo;     // "차량 정보 없음" 등으로 가공된 데이터

    private Integer routeTypeCd; // 버스 유형 코드
    private String routeType;    // "마을버스", "일반버스" 등으로 해석된 문자열
}