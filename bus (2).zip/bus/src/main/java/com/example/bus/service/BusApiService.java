package com.example.bus.service;

import com.example.bus.dto.BusStationDto;
import com.example.bus.dto.BusArrivalInfo;
import com.example.bus.dto.BusRouteStopDto;
import com.example.bus.dto.BusLocationDto;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class BusApiService {

    // 경기도 버스 API 서비스 코드 상수로 정의
    private static final String GYEONGGI_SERVICE_CODE = "/6410000";

    private final WebClient webClient;
    private final String serviceKey;
    private final String baseUrl;

    // WebClient 초기화 및 Service Key 주입
    public BusApiService(WebClient.Builder webClientBuilder,
                         @Value("${api.bus.base-url}") String baseUrl,
                         @Value("${api.bus.service-key}") String serviceKey) {
        this.baseUrl = baseUrl;
        this.webClient = webClientBuilder.baseUrl(baseUrl).build();
        this.serviceKey = serviceKey;
    }

    // 서비스 키 인코딩
    private String getEncodedKey() {
        return URLEncoder.encode(serviceKey, StandardCharsets.UTF_8);
    }

    // 1. 정류소 이름 검색 (searchStation)
    public List<BusStationDto> searchStation(String stationName) {
        String path = GYEONGGI_SERVICE_CODE + "/busstationservice/v2/getBusStationListv2";

        System.out.println("-> [BusApiService/Search] 공공 API 요청 시작 (키워드: " + stationName + ")");

        try {
            Map<String, Object> responseMap = webClient.get()
                    .uri(uriBuilder -> uriBuilder
                            .path(path)
                            .queryParam("serviceKey", getEncodedKey())
                            .queryParam("keyword", stationName)
                            .queryParam("_type", "json")
                            .build())
                    .retrieve()
                    .bodyToMono(Map.class)
                    .block();

            System.out.println("-> [BusApiService/Search] 응답 수신 성공.");

            Map<String, Object> msgBody = (Map<String, Object>) ((Map<String, Object>) responseMap.get("response")).get("msgBody");
            Object listObj = msgBody.get("busStationList");

            // 응답이 단일 객체이거나 리스트일 경우 모두 처리
            List<Map<String, Object>> jsonList = convertToListOfMaps(listObj);

            return jsonList.stream()
                    .map(this::mapToBusStationDtoWithLocation)
                    .collect(Collectors.toList());
        } catch (Exception e) {
            System.err.println("🔥 [BusApiService/Search] 정류소 검색 중 치명적인 오류 발생: " + e.getMessage());
            e.printStackTrace();
            return Collections.emptyList();
        }
    }

    // 2. 버스 도착 정보 가져오기 (fetchBusArrival)
    public List<BusArrivalInfo> fetchBusArrival(String stationId) {
        String path = GYEONGGI_SERVICE_CODE + "/busarrivalservice/v2/getBusArrivalListv2";

        String apiResponse = webClient.get()
                .uri(uriBuilder -> uriBuilder
                        .path(path)
                        .queryParam("serviceKey", getEncodedKey())
                        .queryParam("stationId", stationId)
                        .queryParam("_type", "json")
                        .build())
                .retrieve()
                .onStatus(status -> status.is4xxClientError(), clientResponse -> {
                    System.err.println("❌❌ API CLIENT ERROR: HTTP " + clientResponse.statusCode() + " (Service Key 또는 파라미터 확인 필요)");
                    return clientResponse.bodyToMono(String.class)
                            .flatMap(body -> Mono.error(new RuntimeException("API Client Error " + clientResponse.statusCode() + ": " + body)));
                })
                .onStatus(status -> status.is5xxServerError(), clientResponse -> {
                    System.err.println("❌❌ API SERVER ERROR: HTTP " + clientResponse.statusCode() + " (API 서버 문제 또는 Service Key 확인 필요)");
                    return clientResponse.bodyToMono(String.class)
                            .flatMap(body -> Mono.error(new RuntimeException("API Server Error " + clientResponse.statusCode() + ": " + body)));
                })
                .bodyToMono(String.class)
                .block();

        System.out.println("--- 도착 정보 API 원본 응답 전문 (ID: " + stationId + ") ---");
        System.out.println(apiResponse);
        System.out.println("-----------------------------------------------------");

        try {
            Map<String, Object> responseMap = new ObjectMapper().readValue(apiResponse, Map.class);
            Map<String, Object> responseObj = (Map<String, Object>) responseMap.get("response");
            if (responseObj == null) return Collections.emptyList();
            Map<String, Object> msgBody = (Map<String, Object>) responseObj.get("msgBody");
            if (msgBody == null) return Collections.emptyList();
            Object listObj = msgBody.get("busArrivalList");

            List<Map<String, Object>> jsonList = convertToListOfMaps(listObj);

            return jsonList.stream()
                    .map(this::mapToBusArrivalInfo)
                    .collect(Collectors.toList());
        } catch (Exception e) {
            System.err.println("🔥 [BusApiService/Arrival] 버스 도착 정보 파싱/변환 최종 오류: " + e.getMessage());
            e.printStackTrace();
            return Collections.emptyList();
        }
    }

    // 3. 노선 ID로 정류소 목록을 가져오는 함수 (getBusRoute)
    public List<BusRouteStopDto> getBusRoute(String routeId) {
        String path = GYEONGGI_SERVICE_CODE + "/busrouteservice/v2/getBusRouteStationListv2";

        System.out.println("-> [BusApiService/Route] 공공 API 요청 시작 (노선 ID: " + routeId + ")");

        try {
            Map<String, Object> responseMap = webClient.get()
                    .uri(uriBuilder -> uriBuilder
                            .path(path)
                            .queryParam("serviceKey", getEncodedKey())
                            .queryParam("routeId", routeId)
                            .queryParam("_type", "json")
                            .build())
                    .retrieve()
                    .bodyToMono(Map.class)
                    .block();

            System.out.println("-> [BusApiService/Route] 응답 수신 성공.");

            Map<String, Object> msgBody = (Map<String, Object>) ((Map<String, Object>) responseMap.get("response")).get("msgBody");
            Object listObj = msgBody.get("busRouteStationList");

            List<Map<String, Object>> jsonList = convertToListOfMaps(listObj);

            return jsonList.stream()
                    .map(this::mapToBusRouteStopDto)
                    .collect(Collectors.toList());
        } catch (Exception e) {
            System.err.println("🔥 [BusApiService/Route] 버스 노선 정보 파싱 오류: " + e.getMessage());
            e.printStackTrace();
            return Collections.emptyList();
        }
    }

    // 4. 노선 ID로 실시간 버스 위치 목록을 가져오는 함수
    public List<BusLocationDto> getBusLocations(String routeId) {
        String path = GYEONGGI_SERVICE_CODE + "/buslocationservice/v2/getBusLocationListv2";

        System.out.println("-> [BusApiService/Location] 공공 API 요청 시작 (노선 ID: " + routeId + ")");

        try {
            Map<String, Object> responseMap = webClient.get()
                    .uri(uriBuilder -> uriBuilder
                            .path(path)
                            .queryParam("serviceKey", getEncodedKey())
                            .queryParam("routeId", routeId)
                            .queryParam("_type", "json")
                            .build())
                    .retrieve()
                    .bodyToMono(Map.class)
                    .block();

            System.out.println("-> [BusApiService/Location] 응답 수신 성공.");

            Map<String, Object> responseObj = (Map<String, Object>) responseMap.get("response");
            if (responseObj == null) return Collections.emptyList();
            Map<String, Object> msgBody = (Map<String, Object>) responseObj.get("msgBody");
            if (msgBody == null) {
                System.err.println("버스 위치 정보 파싱 오류: 'msgBody'가 null입니다 (운행 중인 버스 없음).");
                return Collections.emptyList();
            }
            Object listObj = msgBody.get("busLocationList");

            List<Map<String, Object>> jsonList = convertToListOfMaps(listObj);

            return jsonList.stream()
                    .map(this::mapToBusLocationDto)
                    .collect(Collectors.toList());
        } catch (Exception e) {
            System.err.println("🔥 [BusApiService/Location] 버스 위치 정보 파싱 오류: " + e.getMessage());
            e.printStackTrace();
            return Collections.emptyList();
        }
    }

    // 5. 주변 정류소 목록을 가져오는 함수 (searchNearbyStations)
    public List<BusStationDto> searchNearbyStations(double latitude, double longitude, int radius) {
        String path = GYEONGGI_SERVICE_CODE + "/busstationservice/v2/getBusStationAroundListv2";

        System.out.println("-> [BusApiService/Nearby] 공공 API 요청 시작 (lat: " + latitude + ", radius: " + radius + ")");

        String apiResponse = null;

        try {
            apiResponse = webClient.get()
                    .uri(uriBuilder -> uriBuilder
                            .path(path)
                            .queryParam("serviceKey", getEncodedKey())
                            .queryParam("y", latitude)
                            .queryParam("x", longitude)
                            .queryParam("radius", radius)
                            .queryParam("_type", "json")
                            .build())
                    .retrieve()
                    .onStatus(status -> status.is4xxClientError(), clientResponse -> {
                        System.err.println("❌❌ API CLIENT ERROR: HTTP " + clientResponse.statusCode());
                        return clientResponse.bodyToMono(String.class)
                                .flatMap(body -> {
                                    System.err.println("API 에러 응답 본문: " + body);
                                    return Mono.error(new RuntimeException("API Client Error " + clientResponse.statusCode() + ": " + body));
                                });
                    })
                    .onStatus(status -> status.is5xxServerError(), clientResponse -> {
                        System.err.println("❌❌ API SERVER ERROR: HTTP " + clientResponse.statusCode());
                        return clientResponse.bodyToMono(String.class)
                                .flatMap(body -> {
                                    System.err.println("API 에러 응답 본문: " + body);
                                    return Mono.error(new RuntimeException("API Server Error " + clientResponse.statusCode() + ": " + body));
                                });
                    })
                    .bodyToMono(String.class)
                    .block();

            System.out.println("-> [BusApiService/Nearby] 응답 수신 성공.");
            System.out.println("--- 주변 정류소 API 원본 응답 전문 ---");
            System.out.println(apiResponse);
            System.out.println("---------------------------------------");

            Map<String, Object> responseMap = new ObjectMapper().readValue(apiResponse, Map.class);
            Map<String, Object> responseObj = (Map<String, Object>) responseMap.get("response");
            if (responseObj == null) return Collections.emptyList();
            Map<String, Object> msgBody = (Map<String, Object>) responseObj.get("msgBody");
            if (msgBody == null) {
                System.err.println("주변 정류소 검색 오류: API 응답에 'msgBody'가 없습니다.");
                return Collections.emptyList();
            }
            // 주변 정류소 API는 "busStationAroundList"를 사용합니다.
            Object listObj = msgBody.get("busStationAroundList");

            List<Map<String, Object>> jsonList = convertToListOfMaps(listObj);

            return jsonList.stream()
                    .map(this::mapToBusStationDtoWithLocation)
                    .collect(Collectors.toList());
        } catch (Exception e) {
            System.err.println("🔥 [BusApiService/Nearby] 주변 정류소 검색 중 치명적인 오류 발생: " + e.getMessage());
            e.printStackTrace();
            return Collections.emptyList();
        }
    }


    // --- 내부 파싱 및 가공 메서드 ---

    /**
     * API 응답이 단일 객체일 경우 List로 변환하여 반환
     */
    private List<Map<String, Object>> convertToListOfMaps(Object listObj) {
        if (listObj == null) {
            return Collections.emptyList();
        } else if (listObj instanceof List) {
            return (List<Map<String, Object>>) listObj;
        } else if (listObj instanceof Map) {
            return List.of((Map<String, Object>) listObj);
        } else {
            return Collections.emptyList();
        }
    }

    private BusStationDto mapToBusStationDtoWithLocation(Map<String, Object> json) {
        Object stationIdObj = json.get("stationId");
        Object mobileNoObj = json.get("mobileNo");
        Object latObj = json.get("y");
        Object lonObj = json.get("x");

        return new BusStationDto(
                stationIdObj != null ? stationIdObj.toString() : null,
                (String) json.get("stationName"),
                mobileNoObj != null ? mobileNoObj.toString() : null,
                (latObj instanceof Number) ? ((Number) latObj).doubleValue() : 0.0,
                (lonObj instanceof Number) ? ((Number) lonObj).doubleValue() : 0.0
        );
    }

    private BusArrivalInfo mapToBusArrivalInfo(Map<String, Object> json) {
        BusArrivalInfo info = new BusArrivalInfo();

        // 1. 예상 도착 시간 (predictTime1) 파싱 및 가공
        Object predictTimeObj = json.get("predictTime1");
        Integer predictTime = null;
        String arrivalText;
        if (predictTimeObj instanceof Number) {
            predictTime = ((Number) predictTimeObj).intValue();
            arrivalText = predictTime + "분 후";
        } else {
            arrivalText = "정보 없음";
        }

        // ⭐️ [핵심 수정] DTO 변경에 따라 setArrivalInfo() 사용
        info.setPredictTime(predictTime);     // 원본 데이터 (Integer) 저장
        info.setArrivalInfo(arrivalText);    // 가공된 문자열 저장

        // 2. 차량 번호 (plateNo1) 파싱
        Object plateNoObj = json.get("plateNo1");
        String plateText;
        if (plateNoObj == null || plateNoObj.toString().isEmpty()) {
            plateText = "정보 없음";
        } else {
            plateText = plateNoObj.toString();
        }
        info.setPlateNo(plateText);

        // 3. 기타 정보 파싱
        Object routeNameObj = json.get("routeName");
        info.setRouteName(routeNameObj != null ? routeNameObj.toString() : null);

        Object routeIdObj = json.get("routeId");
        info.setRouteId(routeIdObj != null ? routeIdObj.toString() : null);

        Object routeTypeCdObj = json.get("routeTypeCd");
        Integer routeTypeCd = (routeTypeCdObj instanceof Number) ? ((Number) routeTypeCdObj).intValue() : null;

        info.setRouteTypeCd(routeTypeCd);
        info.setRouteType(getRouteTypeName(routeTypeCd));

        return info;
    }

    private String getRouteTypeName(Integer code) {
        if (code == null) return "정보 없음";

        return switch (code) {
            case 11 -> "직행좌석";
            case 12 -> "좌석버스";
            case 13 -> "일반버스";
            case 14 -> "광역버스";
            case 15 -> "경기순환";
            case 16 -> "시외버스";
            case 20 -> "마을버스";
            case 21 -> "따복버스";
            default -> "기타";
        };
    }

    private BusRouteStopDto mapToBusRouteStopDto(Map<String, Object> json) {
        String turnYn = (String) json.get("turnYn");
        // DTO 필드명 통일을 위해 'turnPoint'로 변경
        boolean turnPoint = "Y".equals(turnYn);

        Object stationSeqObj = json.get("stationSeq");
        int stationOrder = (stationSeqObj instanceof Number) ?
                ((Number) stationSeqObj).intValue() :
                0;

        return new BusRouteStopDto(
                json.get("stationId").toString(),
                (String) json.get("stationName"),
                stationOrder,
                turnPoint // 'isTurnPoint' 대신 'turnPoint'로 전달 (DTO 필드명에 맞춤)
        );
    }

    private BusLocationDto mapToBusLocationDto(Map<String, Object> json) {
        Object gpsYObj = json.get("gpsY");
        Object gpsXObj = json.get("gpsX");

        double latitude = (gpsYObj instanceof Number) ?
                ((Number) gpsYObj).doubleValue() :
                0.0;

        double longitude = (gpsXObj instanceof Number) ?
                ((Number) gpsXObj).doubleValue() :
                0.0;

        Object stationSeqObj = json.get("stationSeq");
        int stationOrder = (stationSeqObj instanceof Number) ?
                ((Number) stationSeqObj).intValue() :
                0;

        return new BusLocationDto(
                json.get("stationId").toString(),
                stationOrder,
                (String) json.get("plateNo"),
                latitude,
                longitude
        );
    }
}