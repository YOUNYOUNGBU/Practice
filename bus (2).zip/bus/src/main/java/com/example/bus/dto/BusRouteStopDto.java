// src/main/java/com/example/busapp/dto/BusRouteStopDto.java
package com.example.bus.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BusRouteStopDto {
    private String stationId;
    private String stationName;
    private int stationOrder;      // 노선 순서
    private boolean turnPoint;  // 반환점 여부

    // 추가로 필요한 필드: 경유 시간, 위도/경도 등은 공공 API 명세서에 따라 추가 가능
}