// src/main/java/com/example/bus/dto/BusLocationDto.java
package com.example.bus.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data // Getter, Setter, toString, equals, hashCode 자동 생성 (Lombok 사용 시)
@NoArgsConstructor
@AllArgsConstructor
public class BusLocationDto {
    private String stationId;      // 현재 버스가 위치한 정류소 ID
    private int stationOrder;      // 현재 버스가 위치한 정류소의 '순번'
    private String plateNo;        // 차량 번호

    // ⭐️ 추가: 지도 위에 버스를 표시하기 위해 위도(Y좌표)와 경도(X좌표) 필드를 추가했습니다.
    private double latitude;
    private double longitude;
}