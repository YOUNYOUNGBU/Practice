// src/main/java/com/example/bus/config/CorsConfig.java
package com.example.bus.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration // ⭐️ 이 클래스를 Spring 설정 파일로 등록
public class CorsConfig implements WebMvcConfigurer {

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        // /api 경로로 들어오는 모든 요청에 대해 CORS 설정 적용
        registry.addMapping("/api/**")

                // ⭐️ [수정 완료] Flutter 앱이 실행되는 포트(51619)와 모든 로컬 포트를 허용합니다.
                .allowedOrigins("http://localhost:57148", "http://127.0.0.1:*", "http://localhost:*")

                // 허용할 HTTP 메서드 정의 (GET, POST, PUT, DELETE 등)
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")

                // 요청에 모든 헤더 허용
                .allowedHeaders("*")

                // 인증 정보 (쿠키, HTTP 인증)를 요청에 포함할 수 있도록 허용
                .allowCredentials(true)

                // 브라우저가 preflight 요청 결과를 캐시할 시간 (초)
                .maxAge(3600);
    }
}