// lib/services/bus_api_service.dart

import 'package:http/http.dart' as http;
import 'dart:convert';
// (경로와 프로젝트 이름 확인)
import 'package:bus/models/bus_station.dart';
import 'package:bus/models/bus_arrival_info.dart';
import 'package:bus/models/bus_route_stop.dart';
// ⭐️ [NEW] '버스 위치' 모델 import
import 'package:bus/models/bus_location.dart';

class BusApiService {
  // ⭐️ [수정!] Spring Boot 서버의 기본 URL로 변경
  // 웹 환경에서 테스트 중이므로 'localhost' 사용 (에뮬레이터는 '10.0.2.2')
  final String _baseUrl = 'http://localhost:8080/api';
  // 💡 실제 사용 시에는 'http://[서버 IP]:8080/api'로 변경해야 합니다.

  // 1. (진짜) 정류소 이름으로 검색하는 함수
  Future<List<BusStation>> searchStation(String stationName) async {
    final String url = '$_baseUrl/stations/search?keyword=$stationName';

    try {
      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        final decodedBody = utf8.decode(response.bodyBytes);
        final List<dynamic> jsonList = jsonDecode(decodedBody);
        return jsonList.map((item) => BusStation.fromJson(item)).toList();
      } else {
        throw Exception('정류소 검색 실패! (코드: ${response.statusCode})');
      }
    } catch (e) {
      throw Exception('정류소 검색 중 에러: $e');
    }
  }

  // 2. (진짜) 정류소 ID로 버스 도착 정보를 가져오는 함수 (기존 함수 이름 유지)
  Future<List<BusArrivalInfo>> fetchBusArrival(String stationId) async {
    // 이 함수는 정류장 상세 화면 (BusArrivalDetailScreen)에서 사용합니다.
    final String url = '$_baseUrl/stations/$stationId/arrivals';

    try {
      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        final decodedBody = utf8.decode(response.bodyBytes);
        final List<dynamic> jsonList = jsonDecode(decodedBody);

        // ⭐️ BusArrivalInfo 모델의 새로운 필드(remainingStops)도 파싱되도록 처리
        return jsonList.map((item) => BusArrivalInfo.fromJson(item)).toList();
      } else {
        throw Exception('버스 도착 정보 로딩 실패! (코드: ${response.statusCode})');
      }
    } catch (e) {
      throw Exception('버스 도착 정보 로딩 중 에러: $e');
    }
  }

  // ⭐️ [NEW] 2-1. 특정 노선의 도착 정보를 가져오는 함수 (홈 탭 지원)
  // 노선 ID와 출발 정류장 ID를 기반으로 도착 정보를 가져옵니다.
  Future<BusArrivalInfo?> fetchArrivalInfoByRoute({
    required String stationId,
    required String routeId,
  }) async {
    // ⭐️ 백엔드 URL: /api/stations/{stationId}/arrivals/route/{routeId}
    final String url = '$_baseUrl/stations/$stationId/arrivals/route/$routeId';

    try {
      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        final decodedBody = utf8.decode(response.bodyBytes);
        final Map<String, dynamic> jsonMap = jsonDecode(decodedBody);

        // ⭐️ 백엔드에서 단일 객체를 반환한다고 가정합니다.
        return BusArrivalInfo.fromJson(jsonMap);
      } else if (response.statusCode == 404 || response.statusCode == 204) {
        // 도착 정보가 없는 경우 (예: 운행 종료 등, 204 No Content도 처리)
        return null;
      } else {
        throw Exception('특정 노선 도착 정보 로딩 실패! (코드: ${response.statusCode})');
      }
    } catch (e) {
      throw Exception('특정 노선 도착 정보 로딩 중 에러: $e');
    }
  }

  // ⭐️ [NEW] 2-2. 두 정류장 사이의 공통 노선 목록을 가져오는 함수 (홈 탭 지원)
  Future<List<BusRouteStop>> getRouteBuses({
    required String startStationId,
    required String endStationId,
  }) async {
    // ⭐️ 백엔드 URL: /api/routes/common?startStationId={...}&endStationId={...}
    final String url = '$_baseUrl/routes/common?startStationId=$startStationId&endStationId=$endStationId';

    try {
      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        final decodedBody = utf8.decode(response.bodyBytes);
        final List<dynamic> jsonList = jsonDecode(decodedBody);

        // ⭐️ BusRouteStop 모델을 노선 정보 모델로 임시 활용합니다.
        return jsonList.map((item) => BusRouteStop.fromJson(item)).toList();
      } else {
        throw Exception('경로 노선 목록 로딩 실패! (코드: ${response.statusCode})');
      }
    } catch (e) {
      throw Exception('경로 노선 목록 로딩 중 에러: $e');
    }
  }

  // 3. 노선 ID로 정류소 목록을 가져오는 함수
  Future<List<BusRouteStop>> getBusRoute(String routeId) async {
    final String url = '$_baseUrl/routes/$routeId/stops';

    try {
      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        final decodedBody = utf8.decode(response.bodyBytes);
        final List<dynamic> jsonList = jsonDecode(decodedBody);

        return jsonList.map((item) => BusRouteStop.fromJson(item)).toList();
      } else {
        throw Exception('버스 노선 정보 로딩 실패! (코드: ${response.statusCode})');
      }
    } catch (e) {
      throw Exception('버스 노선 정보 로딩 중 에러: $e');
    }
  }

  // 4. 노선 ID로 '실시간 버스 위치' 목록을 가져오는 함수
  Future<List<BusLocation>> getBusLocations(String routeId) async {
    final String url = '$_baseUrl/routes/$routeId/locations';

    try {
      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        final decodedBody = utf8.decode(response.bodyBytes);
        final List<dynamic> jsonList = jsonDecode(decodedBody);

        return jsonList.map((item) => BusLocation.fromJson(item)).toList();
      } else {
        throw Exception('버스 위치 정보 로딩 실패! (코드: ${response.statusCode})');
      }
    } catch (e) {
      throw Exception('버스 위치 정보 로딩 중 에러: $e');
    }
  }

  // 5. 위도/경도로 주변 정류소 목록을 가져오는 함수
  Future<List<BusStation>> searchNearbyStations(double lat, double lon, int radius) async {
    final String url = '$_baseUrl/stations/nearby?lat=$lat&lon=$lon&radius=$radius';

    try {
      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        final decodedBody = utf8.decode(response.bodyBytes);
        final List<dynamic> jsonList = jsonDecode(decodedBody);

        return jsonList.map((item) => BusStation.fromJson(item)).toList();
      } else {
        throw Exception('주변 정류소 검색 실패! (코드: ${response.statusCode})');
      }
    } catch (e) {
      throw Exception('주변 정류소 검색 중 에러: $e');
    }
  }
}