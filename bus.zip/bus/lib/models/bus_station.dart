// lib/models/bus_station.dart

class BusStation {
  final String stationId;
  final String stationName;
  final String mobileNo;
  // ⭐️ [추가] 주변 검색 결과를 위해 위도/경도 필드 추가
  final double latitude;
  final double longitude;

  BusStation({
    required this.stationId,
    required this.stationName,
    required this.mobileNo,
    required this.latitude,  // ⭐️ 생성자에 추가
    required this.longitude, // ⭐️ 생성자에 추가
  });

  factory BusStation.fromJson(Map<String, dynamic> json) {
    // Spring Boot 서버가 보낸 DTO 필드에 맞춤
    return BusStation(
      stationId: json['stationId'].toString(),
      stationName: json['stationName'] as String,
      mobileNo: json['mobileNo'].toString(),
      // ⭐️ [추가] 서버에서 받은 double 값을 그대로 파싱 (주변 검색 API 응답)
      latitude: (json['latitude'] as num?)?.toDouble() ?? 0.0,
      longitude: (json['longitude'] as num?)?.toDouble() ?? 0.0,
    );
  }
}