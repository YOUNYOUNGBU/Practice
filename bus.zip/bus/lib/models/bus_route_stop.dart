// lib/models/bus_route_stop.dart

class BusRouteStop {
  // ⭐️ [추가] home_tab.dart에서 RouteBusInfo를 생성하기 위해 필요한 필드
  final String? routeId;
  final String? routeName;
  final String? routeType;

  final String stationId;
  final String stationName;
  final int stationOrder;
  final bool isTurnPoint;

  BusRouteStop({
    required this.stationId,
    required this.stationName,
    required this.stationOrder,
    required this.isTurnPoint,
    // ⭐️ [추가] 생성자에 필드 추가
    this.routeId,
    this.routeName,
    this.routeType,
  });

  // ⭐️ [수정!] Spring Boot DTO가 보낸 필드명과 타입에 맞춤
  factory BusRouteStop.fromJson(Map<String, dynamic> json) {
    return BusRouteStop(
      // ⭐️ [추가] JSON 파싱 로직 추가
      routeId: json['routeId']?.toString(),
      routeName: json['routeName']?.toString() ?? '이름 없음',
      routeType: json['routeType']?.toString(),

      stationId: json['stationId'].toString(),
      stationName: json['stationName'] as String? ?? '이름 없음',

      // Spring Boot에서 이미 int 타입으로 가공하여 보냈다고 가정
      stationOrder: json['stationOrder'] as int? ?? 0,

      // Spring Boot에서 이미 boolean 타입으로 변환하여 보냈다고 가정
      isTurnPoint: json['isTurnPoint'] as bool? ?? false,
    );
  }
}