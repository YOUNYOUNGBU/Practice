class BusLocation {
  final String stationId;
  final int stationOrder;
  final String plateNo;

  // ⭐️ [추가!] Spring Boot DTO에 맞게 위도/경도 필드 추가
  final double latitude;
  final double longitude;

  BusLocation({
    required this.stationId,
    required this.stationOrder,
    required this.plateNo,
    required this.latitude,  // ⭐️ 필드 추가
    required this.longitude, // ⭐️ 필드 추가
  });

  // ⭐️ [수정!] Spring Boot DTO가 보낸 필드명과 타입에 맞춤
  factory BusLocation.fromJson(Map<String, dynamic> json) {
    return BusLocation(
      stationId: json['stationId'].toString(),
      stationOrder: json['stationOrder'] as int? ?? 0,
      plateNo: json['plateNo'] as String? ?? '정보 없음',

      // ⭐️ Spring Boot DTO에서 이미 double 타입으로 가공해서 보냈다고 가정
      latitude: json['latitude'] as double? ?? 0.0,
      longitude: json['longitude'] as double? ?? 0.0,
    );
  }
}