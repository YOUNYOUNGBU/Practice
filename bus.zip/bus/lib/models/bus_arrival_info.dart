// lib/models/bus_arrival_info.dart

class BusArrivalInfo {
  // ⭐️ Nullable 필드 유지
  final String? routeId;
  final String? routeName;

  // ⚠️ [수정] arrivalTime 대신 arrivalInfo (가공된 문자열)
  final String? arrivalInfo;

  // ⭐️ [NEW] 추가: 예상 도착 시간 (분 단위) - 에러 해결을 위해 필수
  final int? predictTime;

  final String? plateNo;
  final String? routeType; // ⭐️ 버스 유형 문자열

  // ⭐️ [NEW] 추가: 남은 정류장 수 (HomeTab 기능 지원용)
  final int? remainingStops;

  BusArrivalInfo({
    this.routeId,
    this.routeName,
    this.arrivalInfo, // ⚠️ 수정
    this.predictTime, // ⭐️ 추가
    this.plateNo,
    this.routeType,
    this.remainingStops,
  });

  factory BusArrivalInfo.fromJson(Map<String, dynamic> json) {
    return BusArrivalInfo(
      routeId: json['routeId']?.toString(),
      routeName: json['routeName']?.toString(),

      // ⚠️ [수정] 필드명 변경 반영
      arrivalInfo: json['arrivalInfo']?.toString(),

      // ⭐️ [NEW] 추가: predictTime 파싱
      predictTime: json['predictTime'] is int
          ? json['predictTime']
          : int.tryParse(json['predictTime']?.toString() ?? ''),

      plateNo: json['plateNo']?.toString(),
      routeType: json['routeType']?.toString(),

      remainingStops: json['remainingStops'] is int
          ? json['remainingStops']
          : int.tryParse(json['remainingStops']?.toString() ?? ''),
    );
  }
}