import 'package:flutter/material.dart';
// ⚠️ [수정!] 프로젝트 이름('bus') 확인
import 'package:bus/models/bus_arrival_info.dart';
import 'package:bus/models/bus_station.dart';
import 'package:bus/services/bus_api_service.dart';
// ⭐️ [필수!] 노선 상세 화면 import
import 'package:bus/screens/bus_route_screen.dart';

class BusArrivalDetailScreen extends StatefulWidget {
  final BusStation station;
  const BusArrivalDetailScreen({Key? key, required this.station}) : super(key: key);

  @override
  State<BusArrivalDetailScreen> createState() => _BusArrivalDetailScreenState();
}

class _BusArrivalDetailScreenState extends State<BusArrivalDetailScreen> {
  final BusApiService _apiService = BusApiService();
  late Future<List<BusArrivalInfo>> _arrivalInfoFuture;

  @override
  void initState() {
    super.initState();
    // 2. 전달받은 'stationId'로 버스 정보를 로드
    _arrivalInfoFuture = _apiService.fetchBusArrival(widget.station.stationId);
  }

  void _refreshArrivalInfo() {
    setState(() {
      _arrivalInfoFuture = _apiService.fetchBusArrival(widget.station.stationId);
    });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('버스 정보를 새로고침했습니다.'), duration: Duration(seconds: 1)),
    );
  }

  // ⭐️ [NEW] 에러 시 보여줄 UI
  Widget _buildErrorView(String message) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.error_outline, size: 60, color: Colors.redAccent),
          const SizedBox(height: 10),
          Text(
            message,
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 16, color: Colors.grey[600]),
          ),
        ],
      ),
    );
  }

  // ⭐️ [NEW] 버스 유형에 따른 뱃지 색상을 결정하는 함수
  Color _getBadgeColor(String type) {
    return switch (type) {
      '마을버스' => Colors.lightGreen,
      '직행좌석' => Colors.redAccent,
      '광역버스' => Colors.purpleAccent,
      _ => Colors.blueGrey, // 일반버스, 기타 등
    };
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.station.stationName),
        actions: [
          IconButton(
            icon: const Icon(Icons.cached),
            onPressed: _refreshArrivalInfo,
            tooltip: '새로고침',
          ),
        ],
        // ⭐️ [디자인] AppBar에 정류소 번호(mobileNo)도 표시
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(30.0),
          child: Container(
            padding: const EdgeInsets.only(bottom: 8.0),
            alignment: Alignment.center,
            child: Text(
              '정류소 번호: ${widget.station.mobileNo ?? '정보 없음'}',
              style: TextStyle(color: Colors.black87.withOpacity(0.8), fontSize: 14),
            ),
          ),
        ),
      ),
      body: FutureBuilder<List<BusArrivalInfo>>(
        future: _arrivalInfoFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator(color: Theme.of(context).primaryColor));
          }
          if (snapshot.hasError) {
            return _buildErrorView('버스 정보 로딩 중 오류가 발생했습니다.\n${snapshot.error}');
          }
          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            // ⭐️ 수정된 에러 메시지: 도착 예정 정보가 없는 이유를 안내
            return _buildErrorView(
                '현재 도착 예정인 버스가 없습니다.\n\n'
                    '❗️해당 노선이 미운행 중이거나 공공 API의 실시간 정보 오류일 수 있습니다.'
            );
          }

          final arrivals = snapshot.data!;

          // ⭐️ [디자인] ListView.separated로 구분선 디자인 적용
          return ListView.separated(
            padding: const EdgeInsets.symmetric(vertical: 8.0),
            itemCount: arrivals.length,
            separatorBuilder: (context, index) => Divider(
              height: 1,
              thickness: 1,
              color: Colors.grey[200],
              indent: 20,
              endIndent: 20,
            ),
            itemBuilder: (context, index) {
              final arrival = arrivals[index];
              final String routeType = arrival.routeType ?? '기타';

              // ⭐️ [수정] predictTime 필드를 사용하여 분 단위 시간 정보를 가져옵니다.
              final String arrivalTimeDisplay = arrival.predictTime != null
                  ? '${arrival.predictTime}분 후'
                  : arrival.arrivalInfo ?? '도착 정보 없음';

              // ⭐️ [디자인] 탭(클릭)이 가능한 '잉크웰' 효과
              return InkWell(
                onTap: () {
                  // ⭐️ [NEW] 노선 보기 기능 (routeId가 null/빈 값이 아닐 때만 이동)
                  final String routeId = arrival.routeId ?? '';
                  final String routeName = arrival.routeName ?? '노선 정보 없음';

                  if (routeId.isNotEmpty) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => BusRouteScreen(
                          routeId: routeId,
                          routeName: routeName,
                        ),
                      ),
                    );
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('노선 ID가 없어 상세 정보를 볼 수 없습니다.')),
                    );
                  }
                },

                // ⭐️ [디자인] 트렌디한 Row 디자인 적용
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 16.0),
                  child: Row(
                    children: [
                      // 1. (버스 번호 + 유형 뱃지)
                      SizedBox(
                        width: 90, // ⭐️ 너비를 넓혀 유형 뱃지를 포함할 공간 확보
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              arrival.routeName ?? '노선명', // ⭐️ [수정!] 'No Route' 대신 '노선명'
                              style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                color: Theme.of(context).primaryColor,
                              ),
                            ),
                            const SizedBox(height: 4),
                            // ⭐️ [NEW] 버스 유형 뱃지 표시
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(
                                color: _getBadgeColor(routeType), // ⭐️ 유형에 따른 색상 적용
                                borderRadius: BorderRadius.circular(4),
                              ),
                              child: Text(
                                routeType,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 10,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),

                      // 2. (도착 시간 + 차량 번호) - (가운데 영역 차지)
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              arrivalTimeDisplay, // ⭐️ [수정] predictTime 사용
                              style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.deepOrange,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              arrival.plateNo ?? '차량 정보 없음', // ⭐️ [Null Safe]
                              style: TextStyle(color: Colors.grey[600], fontSize: 13),
                            ),
                          ],
                        ),
                      ),

                      // 3. (>) 아이콘
                      Icon(Icons.chevron_right, color: Colors.grey[400], size: 28),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}