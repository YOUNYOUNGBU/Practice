// lib/screens/tabs/nearby_tab.dart

import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:bus/services/bus_api_service.dart';
import 'package:bus/models/bus_station.dart';
import 'package:bus/screens/bus_arrival_detail_screen.dart';

// ⭐️ Flutter Map 및 LatLng2 사용
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

class NearbyTab extends StatefulWidget {
  const NearbyTab({Key? key}) : super(key: key);

  @override
  State<NearbyTab> createState() => _NearbyTabState();
}

class _NearbyTabState extends State<NearbyTab> {
  final BusApiService _apiService = BusApiService();
  Future<List<BusStation>>? _nearbyStationsFuture;
  Position? _currentPosition;

  // ⭐️ [NEW] 반경 설정 목록 대신 고정된 기본 반경 사용
  final int _fixedRadius = 500; // 고정된 반경 값 (500m)

  // ⭐️ Flutter Map 관련 변수
  final MapController _mapController = MapController();
  List<Marker> _markers = [];
  bool _mapReady = false;

  // 서울 시청 근처 기본 위치 (지도 초기화용)
  static const LatLng _initialCenter = LatLng(37.5665, 126.9780);

  @override
  void initState() {
    super.initState();
    _checkLocationAndLoad();
  }

  // ⭐️ [수정] _checkLocationAndLoad 함수에서 반경 선택 로직 제거, 고정값 사용
  Future<void> _checkLocationAndLoad() async {
    // 1. 초기 상태 설정
    setState(() {
      _mapReady = false;
      _markers = [];
      _nearbyStationsFuture = null;
    });

    bool serviceEnabled;
    LocationPermission permission;

    // 2. 위치 권한 확인 로직
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      setState(() => _nearbyStationsFuture = Future.error('위치 서비스를 활성화해주세요.'));
      return;
    }
    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        setState(() => _nearbyStationsFuture = Future.error('위치 권한이 거부되었습니다.'));
        return;
      }
    }
    if (permission == LocationPermission.deniedForever) {
      setState(() => _nearbyStationsFuture = Future.error('위치 권한을 영구적으로 허용해주세요.'));
      return;
    }

    // 3. 현재 위치 가져오기
    try {
      Position position = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.medium
      );
      _currentPosition = position;

      final currentLatLng = LatLng(position.latitude, position.longitude);

      // ⭐️ 3-1. 지도 중앙 이동: move 메서드 사용
      _mapController.move(currentLatLng, 16.0);

      // 4. API 호출 (⭐️ 고정된 반경 값 _fixedRadius 전달)
      _nearbyStationsFuture = _apiService.searchNearbyStations(
        position.latitude,
        position.longitude,
        _fixedRadius, // ⭐️ 고정 반경 값 전달
      );

      // 5. 정류소 데이터를 마커로 변환하여 지도에 업데이트
      await _updateMapMarkers(await _nearbyStationsFuture!);

      if (mounted) {
        setState(() {
          _mapReady = true;
        });
      }

    } catch (e) {
      setState(() {
        _nearbyStationsFuture = Future.error('위치 정보를 가져오는 중 오류 발생: $e');
        _mapReady = true;
      });
    }
  }

  // ⭐️ 정류소 데이터를 Flutter Map 마커로 변환 (디자인 강조)
  Future<void> _updateMapMarkers(List<BusStation> stations) async {
    final List<Marker> newMarkers = [];

    // 1. 현재 위치 마커 추가 (파란색 도트 위젯)
    if (_currentPosition != null) {
      newMarkers.add(
        Marker(
          width: 40.0,
          height: 40.0,
          point: LatLng(_currentPosition!.latitude, _currentPosition!.longitude),
          // 현재 위치 마커 강조 디자인 유지
          child: Container(
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white,
              border: Border.all(color: Colors.blue, width: 2),
            ),
            child: const Icon(Icons.location_pin, color: Colors.blue, size: 28),
          ),
        ),
      );
    }

    // 2. 버스 정류소 마커 추가
    for (var station in stations) {
      newMarkers.add(
        Marker(
          width: 35.0, // ⭐️ [축소] 마커 크기를 35.0으로 축소
          height: 35.0, // ⭐️ [축소] 마커 크기를 35.0으로 축소
          point: LatLng(station.latitude, station.longitude),
          child: GestureDetector(
            onTap: () {
              _navigateToDetail(station);
            },
            // ⭐️ 버스 정류소 마커 강조 디자인 유지 및 크기 축소
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white, // 흰색 배경
                shape: BoxShape.circle,
                border: Border.all(color: Colors.redAccent, width: 3.5), // 테두리 두께 강화
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.4), // 그림자 진하게
                    blurRadius: 5,
                  ),
                ],
              ),
              child: const Icon(
                  Icons.directions_bus,
                  color: Colors.redAccent,
                  size: 22 // ⭐️ [축소] 아이콘 크기를 22로 축소
              ),
            ),
          ),
        ),
      );
    }

    if (mounted) {
      setState(() {
        _markers = newMarkers;
      });
    }
  }

  // ⭐️ 상세 화면 이동 함수
  void _navigateToDetail(BusStation station) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => BusArrivalDetailScreen(station: station),
      ),
    );
  }

  // ⭐️ [제거] 반경 설정 변경 함수 제거 (사용자 선택 기능 제거)
  // void _changeRadius(int? newRadius) { ... }


  @override
  Widget build(BuildContext context) {
    final initialCenter = _currentPosition != null
        ? LatLng(_currentPosition!.latitude, _currentPosition!.longitude)
        : _initialCenter;

    return Scaffold(
      appBar: AppBar(
        title: const Text('📍 내 주변 정류소'),
        actions: [
          // ⭐️ [제거] 반경 선택 드롭다운 버튼 제거

          // ⭐️ [수정] 새로고침 버튼만 유지
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _checkLocationAndLoad,
            tooltip: '위치 및 정류소 새로고침',
          ),
        ],
      ),
      body: Stack(
        children: [
          // ⭐️ 1. FlutterMap 위젯 (무료 OSM 지도 표시)
          FlutterMap(
            mapController: _mapController,
            options: MapOptions(
              initialCenter: initialCenter,
              initialZoom: 15,
              onMapReady: () {
                if (mounted) {
                  setState(() {
                    _mapReady = true;
                  });
                }
              },
            ),
            children: [
              // ⭐️ 지도 타일 레이어를 OpenStreetMap(OSM) 기본 URL로 변경
              TileLayer(
                urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                userAgentPackageName: 'com.example.bus',
              ),

              // ⭐️ 마커 레이어
              MarkerLayer(markers: _markers),
            ],
          ),

          // ⭐️ 로딩 인디케이터
          if (!_mapReady && _currentPosition == null)
            const Center(child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CircularProgressIndicator(),
                SizedBox(height: 10),
                Text('지도 및 위치 확인 중...')
              ],
            )),

          // ⭐️ 2. 하단 리스트 뷰 (정류소 목록)
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              height: 250,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(20),
                  topRight: Radius.circular(20),
                ),
                boxShadow: [
                  BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 10),
                ],
              ),
              child: FutureBuilder<List<BusStation>>(
                future: _nearbyStationsFuture,
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return _mapReady
                        ? const Center(child: CircularProgressIndicator())
                        : Container();
                  }

                  if (snapshot.hasError) {
                    // ⭐️ API/위치 권한 오류 메시지 표시
                    return Center(child: Text('오류: ${snapshot.error}', textAlign: TextAlign.center));
                  }
                  if (!snapshot.hasData || snapshot.data!.isEmpty) {
                    return const Center(child: Text('주변에 정류소가 없거나 데이터를 로드할 수 없습니다.'));
                  }

                  final stations = snapshot.data!;

                  return Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Text(
                          '주변 정류소 (${stations.length}개)',
                          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                        ),
                      ),
                      Expanded(
                        child: ListView.builder(
                          itemCount: stations.length,
                          itemBuilder: (context, index) {
                            final station = stations[index];
                            return ListTile(
                              leading: const Icon(Icons.directions_bus, color: Color(0xFF007AFF)), // 앱 테마 색상으로 조정
                              title: Text(station.stationName, style: const TextStyle(fontWeight: FontWeight.bold)),
                              subtitle: Text('번호: ${station.mobileNo}'),
                              trailing: const Icon(Icons.arrow_forward_ios),
                              onTap: () {
                                _navigateToDetail(station);
                                // ⭐️ 리스트 항목 탭 시 지도를 해당 정류소로 이동
                                _mapController.move(
                                    LatLng(station.latitude, station.longitude),
                                    16.0
                                );
                              },
                            );
                          },
                        ),
                      ),
                    ],
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}