import 'package:flutter/material.dart';
// ⚠️ [수정!] 프로젝트 이름('bus') 확인
import 'package:bus/models/bus_station.dart';
import 'package:bus/services/favorite_service.dart';
// ⬇️ [수정!] 'detail_screen'이 아니라, 'card' 위젯을 import
import 'package:bus/widgets/favorite_station_card.dart';

class FavoriteTab extends StatefulWidget {
  const FavoriteTab({Key? key}) : super(key: key);

  @override
  State<FavoriteTab> createState() => _FavoriteTabState();
}

class _FavoriteTabState extends State<FavoriteTab> {
  final FavoriteService _favoriteService = FavoriteService();
  late Future<List<BusStation>> _favoritesFuture;

  @override
  void initState() {
    super.initState();
    _loadFavorites();
  }

  // (기존) 즐겨찾기 목록 로드
  void _loadFavorites() {
    setState(() {
      _favoritesFuture = _favoriteService.getFavorites();
    });
  }

  // ⭐️ [NEW] '당겨서 새로고침'을 처리할 함수
  Future<void> _onRefresh() async {
    // setState()를 호출해서 _favoritesFuture를 새 Future로 교체합니다.
    // 그러면 FutureBuilder가 자동으로 재실행됩니다.
    setState(() {
      _favoritesFuture = _favoriteService.getFavorites();
    });
    // RefreshIndicator가 로딩 스피너를 멈출 수 있도록 Future를 반환합니다.
    await _favoritesFuture;
  }

  // (1) 즐겨찾기 삭제
  void _removeFavorite(String stationId) async {
    await _favoriteService.removeFavorite(stationId);
    _loadFavorites(); // 목록 새로고침
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('즐겨찾기에서 삭제되었습니다.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('⭐ 나의 즐겨찾기'),
      ),
      // ⭐️ [수정!] body 전체를 RefreshIndicator로 감쌌습니다.
      body: RefreshIndicator(
        onRefresh: _onRefresh, // ⭐️ 당기면 _onRefresh 함수 실행
        color: Theme.of(context).primaryColor, // ⭐️ 로딩 스피너 색상
        child: FutureBuilder<List<BusStation>>(
          future: _favoritesFuture,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting && snapshot.data == null) {
              // (최초 로딩 시에만 스피너 표시)
              return Center(child: CircularProgressIndicator(color: Theme.of(context).primaryColor));
            }
            if (snapshot.hasError) {
              return Center(child: Text('오류: ${snapshot.error}'));
            }
            if (!snapshot.hasData || snapshot.data!.isEmpty) {
              // (목록이 비었을 때 - '당겨서 새로고침'을 유도)
              return Center(
                child: SingleChildScrollView( // (당길 수 있도록 스크롤 뷰 추가)
                  physics: const AlwaysScrollableScrollPhysics(),
                  child: Container(
                    height: MediaQuery.of(context).size.height * 0.7, // (화면 높이)
                    alignment: Alignment.center,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.stars_outlined, size: 60, color: Colors.grey[400]),
                        const SizedBox(height: 10),
                        Text(
                          '아직 즐겨찾는 정류소가 없어요!\n\'검색\' 탭에서 추가 후 당겨서 새로고침하세요.',
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 16, color: Colors.grey[600]),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            }

            final favorites = snapshot.data!;

            // (목록 표시)
            return ListView.builder(
              // ⭐️ 항상 당길 수 있도록 physics 추가
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.only(top: 8, bottom: 8),
              itemCount: favorites.length,
              itemBuilder: (context, index) {
                final station = favorites[index];
                return FavoriteStationCard(
                  station: station,
                  onRemove: () => _removeFavorite(station.stationId),
                );
              },
            );
          },
        ),
      ),
    );
  }
}