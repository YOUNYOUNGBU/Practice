// lib/screens/tabs/home_tab.dart

import 'package:flutter/material.dart';
import 'package:bus/models/bus_station.dart';
import 'package:bus/models/bus_arrival_info.dart';
import 'package:bus/services/bus_api_service.dart';
import 'package:bus/models/bus_route_stop.dart';
// ⭐️ [필수] MainScreen.dart가 HomeTab, SearchTab 등을 포함하는 경우, 이 위젯은 HomeTab입니다.

// ⭐️ 데이터 모델: 경로 버스 목록을 담을 간단한 모델
class RouteBusInfo {
  final String routeId;
  final String routeName;
  final String routeType;

  RouteBusInfo({required this.routeId, required this.routeName, required this.routeType});
}

// ⚠️ [임시] 정류장 검색 화면 (실제 로직은 SearchTab 등을 활용해야 함)
class SearchStationScreen extends StatelessWidget {
  final String title;
  const SearchStationScreen({Key? key, required this.title}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            // 더미 데이터 반환 (실제 앱에서는 검색 결과를 반환해야 함)
            // ⭐️ [수정] stationId도 함께 반환
            Navigator.pop(context, BusStation(stationId: '12345', stationName: '강남역 (중)', mobileNo: '22000', latitude: 37.4979, longitude: 127.0276));
          },
          child: const Text('임시 정류장 선택 (클릭 시 강남역 반환)'),
        ),
      ),
    );
  }
}


class HomeTab extends StatefulWidget {
  const HomeTab({Key? key}) : super(key: key);

  @override
  State<HomeTab> createState() => _HomeTabState();
}

class _HomeTabState extends State<HomeTab> {
  final BusApiService _apiService = BusApiService();

  // ⭐️ [수정] 정류장 ID/이름을 포함하는 BusStation 객체 사용
  BusStation? _startStation;
  BusStation? _endStation;

  // 선택된 버스 노선 정보
  RouteBusInfo? _selectedBus;

  // 선택된 버스의 도착 정보 (몇 정거장 남았는지 표시용)
  Future<BusArrivalInfo?>? _arrivalInfoFuture;

  // 해당 경로를 운행하는 버스 목록
  List<RouteBusInfo> _routeBusList = [];
  bool _isLoading = false;
  String? _errorMessage;

  // ⭐️ 2. 경로 버스 목록 조회 (API 호출)
  Future<void> _fetchRouteBuses() async {
    // ⭐️ [수정] ID를 사용
    final startId = _startStation?.stationId;
    final endId = _endStation?.stationId;

    if (startId == null || endId == null) return;

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _routeBusList = [];
      _selectedBus = null;
      _arrivalInfoFuture = null;
    });

    try {
      // ⭐️ [API 연동] getRouteBuses 사용
      final List<BusRouteStop> routeStops = await _apiService.getRouteBuses(
        startStationId: startId, // ID 전달
        endStationId: endId, // ID 전달
      );

      // ⭐️ BusRouteStop을 RouteBusInfo로 변환 (nullable 필드 안전하게 처리)
      _routeBusList = routeStops
          .where((item) => item.routeId != null && item.routeName != null && item.routeType != null)
          .map((item) => RouteBusInfo(
        routeId: item.routeId!,
        routeName: item.routeName!,
        routeType: item.routeType!,
      ))
          .toList();

    } catch (e) {
      _errorMessage = "버스 노선 조회 중 오류 발생: $e";
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  // ⭐️ 3. 버스 선택 및 도착 정보 조회
  Future<void> _selectBus(RouteBusInfo bus) async {
    final startId = _startStation?.stationId; // ID 사용
    if (startId == null) return;

    setState(() {
      _selectedBus = bus;

      // ⭐️ [수정] API 서비스에 정의된 fetchArrivalInfoByRoute 사용
      _arrivalInfoFuture = _apiService.fetchArrivalInfoByRoute(
          stationId: startId, // ID 전달
          routeId: bus.routeId
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('🚌 홈 - 경로 찾기'),
        backgroundColor: Colors.blueAccent,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // --- 1. 출발/도착 정류장 설정 UI ---
            _buildStationInput(
              label: '출발 정류장',
              currentValue: _startStation?.stationName ?? '정류장 선택', // ⭐️ 객체의 이름 사용
              onTap: () async {
                final selectedStation = await Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const SearchStationScreen(title: '출발 정류장 검색')),
                );
                if (selectedStation != null && selectedStation is BusStation) {
                  setState(() {
                    _startStation = selectedStation; // ⭐️ 객체 저장
                  });
                  _fetchRouteBuses();
                }
              },
            ),
            const SizedBox(height: 10),
            // 경로 전환 버튼 (출발/도착 스왑)
            Center(
              child: IconButton(
                icon: const Icon(Icons.swap_vert, color: Colors.grey),
                onPressed: () {
                  setState(() {
                    final temp = _startStation;
                    _startStation = _endStation;
                    _endStation = temp;
                  });
                  _fetchRouteBuses();
                },
              ),
            ),
            const SizedBox(height: 10),
            _buildStationInput(
              label: '도착 정류장',
              currentValue: _endStation?.stationName ?? '정류장 선택', // ⭐️ 객체의 이름 사용
              onTap: () async {
                final selectedStation = await Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const SearchStationScreen(title: '도착 정류장 검색')),
                );
                if (selectedStation != null && selectedStation is BusStation) {
                  setState(() {
                    _endStation = selectedStation; // ⭐️ 객체 저장
                  });
                  _fetchRouteBuses();
                }
              },
            ),

            const SizedBox(height: 30),
            const Divider(),

            // --- 2. 경로 버스 목록 표시 ---
            // ⭐️ [수정] 객체가 설정되었는지 확인
            (_startStation != null && _endStation != null) || _isLoading
                ? _buildRouteBusList()
                : const Padding(
              padding: EdgeInsets.symmetric(vertical: 20.0),
              child: Center(child: Text('출발 정류장과 도착 정류장을 설정해주세요.')),
            ),

            const SizedBox(height: 20),

            // --- 3. 선택된 버스의 도착 정보 표시 ---
            _selectedBus != null ? _buildArrivalInfo() : Container(),
          ],
        ),
      ),
    );
  }

  // ⭐️ [이동/통합] _buildStationInput 메소드 (클래스 내부로 이동)
  Widget _buildStationInput({required String label, required String currentValue, required VoidCallback onTap}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        const SizedBox(height: 8),
        GestureDetector(
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 15),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey.shade300),
              borderRadius: BorderRadius.circular(8),
              color: Colors.grey.shade50,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Flexible(
                  child: Text(
                    currentValue,
                    style: TextStyle(
                      fontSize: 16,
                      color: currentValue == '정류장 선택' ? Colors.grey : Colors.black,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                const Icon(Icons.search, color: Colors.grey),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // ... (나머지 _buildRouteBusList, _buildArrivalInfo는 아래에 정의됨)

  Widget _buildRouteBusList() {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (_errorMessage != null) {
      return Center(
        child: Text(_errorMessage!, style: const TextStyle(color: Colors.red)),
      );
    }

    if (_routeBusList.isEmpty) {
      return const Center(
        child: Text('검색 결과가 없습니다. 다른 경로를 시도해보세요.'),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          '경로 버스 선택 (${_routeBusList.length}개)',
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 10),
        ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: _routeBusList.length,
          itemBuilder: (context, index) {
            final bus = _routeBusList[index];
            final isSelected = _selectedBus?.routeId == bus.routeId;

            return Card(
              color: isSelected ? Colors.blue.shade50 : Colors.white,
              margin: const EdgeInsets.only(bottom: 8),
              child: ListTile(
                leading: Container(
                  width: 50,
                  height: 30,
                  decoration: BoxDecoration(
                    color: bus.routeType.contains('광역') ? Colors.redAccent : Colors.blue,
                    borderRadius: BorderRadius.circular(4),
                  ),
                  alignment: Alignment.center,
                  child: Text(bus.routeType, style: const TextStyle(color: Colors.white, fontSize: 12)),
                ),
                title: Text(bus.routeName, style: const TextStyle(fontWeight: FontWeight.bold)),
                // ⭐️ [수정] 객체의 이름을 사용
                subtitle: Text('출발: ${_startStation!.stationName}, 도착: ${_endStation!.stationName}'),
                trailing: isSelected ? const Icon(Icons.check_circle, color: Colors.blue) : null,
                onTap: () => _selectBus(bus),
              ),
            );
          },
        ),
      ],
    );
  }

  Widget _buildArrivalInfo() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          '✅ 선택된 버스 도착 정보',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.blueAccent),
        ),
        const SizedBox(height: 10),
        Card(
          elevation: 4,
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: FutureBuilder<BusArrivalInfo?>(
              future: _arrivalInfoFuture,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }

                if (snapshot.hasError || !snapshot.hasData || snapshot.data == null) {
                  return const Text('도착 정보를 불러올 수 없습니다.', style: TextStyle(color: Colors.red));
                }

                final info = snapshot.data!;
                final remainingStops = info.remainingStops;
                final predictTime = info.predictTime; // ⭐️ predictTime 필드 사용

                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '노선: ${_selectedBus!.routeName}',
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    // ⭐️ 몇 정거장 뒤에 도착하는지 표시
                    Text(
                      '다음 도착 차량: ${remainingStops != null ? '${remainingStops} 정거장 뒤 도착' : '도착 정보 없음'}',
                      style: const TextStyle(fontSize: 20, color: Colors.green, fontWeight: FontWeight.w700),
                    ),
                    const SizedBox(height: 4),
                    // ⭐️ predictTime 필드를 사용
                    Text('예상 시간: ${predictTime != null ? '${predictTime}분' : info.arrivalInfo ?? '정보 없음'}'),
                  ],
                );
              },
            ),
          ),
        ),
      ],
    );
  }
}