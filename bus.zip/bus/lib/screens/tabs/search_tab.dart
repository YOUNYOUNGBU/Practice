import 'package:flutter/material.dart';
// (import 구문들은 동일)
import 'package:bus/models/bus_station.dart';
import 'package:bus/services/bus_api_service.dart';
import 'package:bus/services/favorite_service.dart';
import 'package:bus/screens/bus_arrival_detail_screen.dart';

class SearchTab extends StatefulWidget {
  const SearchTab({Key? key}) : super(key: key);

  @override
  State<SearchTab> createState() => _SearchTabState();
}

class _SearchTabState extends State<SearchTab> {
  // --- (모든 함수: initState, _loadFavoriteStates, _searchStation, _toggleFavorite, _navigateToDetail, _showSnackBar는 이전 코드와 동일합니다) ---
  // ... (서비스, 컨트롤러 선언 동일) ...
  final BusApiService _apiService = BusApiService();
  final FavoriteService _favoriteService = FavoriteService();
  final TextEditingController _searchController = TextEditingController();

  List<BusStation> _searchResult = [];
  bool _isStationSearching = false;
  final Map<String, bool> _favoriteStates = {};

  @override
  void initState() {
    super.initState();
  }

  Future<void> _loadFavoriteStates() async {
    final newStates = <String, bool>{};
    for (var station in _searchResult) {
      bool isFav = await _favoriteService.isFavorite(station.stationId);
      newStates[station.stationId] = isFav;
    }
    if (mounted) {
      setState(() {
        _favoriteStates.addAll(newStates);
      });
    }
  }

  void _searchStation() async {
    final stationName = _searchController.text;
    if (stationName.isEmpty) {
      _showSnackBar('정류소 이름을 입력해 주세요.');
      return;
    }
    FocusScope.of(context).unfocus();

    setState(() {
      _isStationSearching = true;
      _searchResult = [];
      _favoriteStates.clear();
    });
    try {
      final stations = await _apiService.searchStation(stationName);
      setState(() {
        _searchResult = stations;
      });
      _loadFavoriteStates();
    } catch (e) {
      _showSnackBar('정류소 검색 실패: $e');
    } finally {
      if (mounted) {
        setState(() {
          _isStationSearching = false;
        });
      }
    }
  }

  void _toggleFavorite(BusStation station) async {
    bool isAlreadyFavorite = _favoriteStates[station.stationId] ?? false;
    if (isAlreadyFavorite) {
      await _favoriteService.removeFavorite(station.stationId);
      _showSnackBar('${station.stationName} 즐겨찾기 제거');
    } else {
      await _favoriteService.addFavorite(station);
      _showSnackBar('${station.stationName} 즐겨찾기 추가');
    }
    setState(() {
      _favoriteStates[station.stationId] = !isAlreadyFavorite;
    });
  }

  void _navigateToDetail(BusStation station) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => BusArrivalDetailScreen(station: station),
      ),
    );
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).removeCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(message), duration: const Duration(seconds: 2))
    );
  }
  // --- (여기까지 모든 함수 동일) ---


  @override
  Widget build(BuildContext context) {
    final themeColor = Theme.of(context).primaryColor;

    return Scaffold(
      appBar: AppBar(
        title: const Text('🔍 정류소 검색'),
      ),
      body: Column(
        children: [
          // --- 1. 검색창 영역 (이전 '트렌디' 디자인과 동일) ---
          Container(
            color: Colors.white,
            padding: const EdgeInsets.fromLTRB(16.0, 8.0, 16.0, 16.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _searchController,
                    decoration: InputDecoration(
                      hintText: '정류소 이름 (예: 수원역)',
                      hintStyle: TextStyle(color: Colors.grey[400], fontSize: 16),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide.none,
                      ),
                      filled: true,
                      fillColor: Theme.of(context).scaffoldBackgroundColor,
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                      prefixIcon: Icon(Icons.search, color: Colors.grey[500]),
                    ),
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                    onSubmitted: (value) => _searchStation(),
                  ),
                ),
                const SizedBox(width: 12),
                ElevatedButton(
                  onPressed: _searchStation,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: themeColor,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    padding: const EdgeInsets.all(16),
                    elevation: 2,
                  ),
                  child: const Icon(Icons.arrow_forward_rounded),
                ),
              ],
            ),
          ),
          Container(
            height: 1,
            color: Colors.grey[200],
          ),

          // --- 2. 검색 결과 영역 ---
          Expanded(
            child: _buildResultArea(),
          ),
        ],
      ),
    );
  }

  Widget _buildResultArea() {
    if (_isStationSearching) {
      return Center(child: CircularProgressIndicator(color: Theme.of(context).primaryColor));
    }
    if (_searchResult.isEmpty) {
      // (검색 결과 없음 UI - 동일)
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.location_city_rounded, size: 80, color: Colors.grey[300]),
            const SizedBox(height: 15),
            Text(
              '찾으시는 정류소가 있으신가요?',
              style: TextStyle(fontSize: 17, color: Colors.grey[500], fontWeight: FontWeight.w500),
            ),
            const SizedBox(height: 5),
            Text(
              '위 검색창에 정류소 이름을 입력해주세요.',
              style: TextStyle(fontSize: 14, color: Colors.grey[400]),
            ),
          ],
        ),
      );
    }

    // (검색 결과 리스트)
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 60),
      itemCount: _searchResult.length,
      itemBuilder: (context, index) {
        final station = _searchResult[index];
        bool isFavorite = _favoriteStates[station.stationId] ?? false;

        // ⭐️ [디자인 수정] 'Card' 위젯을 명시적으로 사용
        return Card(
          // (CardTheme이 적용됨: color: white, shape: rounded(16))
          elevation: 2, // (그림자 살짝)
          shadowColor: Colors.black.withOpacity(0.1), // (그림자 색 연하게)
          margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
          child: InkWell( // ⭐️ Card 위에 클릭 효과(InkWell)를 씌움
            onTap: () => _navigateToDetail(station),
            borderRadius: BorderRadius.circular(16), // (InkWell 효과도 둥글게)
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
              child: Row(
                children: [
                  // (아이콘)
                  Icon(Icons.location_on_outlined, color: Theme.of(context).primaryColor, size: 28),
                  const SizedBox(width: 16),
                  // (텍스트)
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          station.stationName,
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 17,
                            color: Colors.black87,
                          ),
                          maxLines: 2, // (이름이 길 경우 2줄까지)
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 4),
                        Text(
                          '번호: ${station.mobileNo}',
                          style: TextStyle(color: Colors.grey[600], fontSize: 14),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  // (즐겨찾기 버튼)
                  IconButton(
                    icon: Icon(
                      isFavorite ? Icons.star_rounded : Icons.star_outline_rounded,
                      color: isFavorite ? Colors.amber[600] : Colors.grey[300],
                      size: 30,
                    ),
                    onPressed: () => _toggleFavorite(station),
                    tooltip: isFavorite ? '즐겨찾기에서 제거' : '즐겨찾기 추가',
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}