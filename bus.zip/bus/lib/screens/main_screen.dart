// lib/screens/main_screen.dart

import 'package:flutter/material.dart';
import 'package:bus/screens/tabs/home_tab.dart';
import 'package:bus/screens/tabs/search_tab.dart';
import 'package:bus/screens/tabs/nearby_tab.dart';
import 'package:bus/screens/tabs/favorite_tab.dart';

// 앱의 최상위 위젯 (BottomNavigationBar를 관리)
class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _selectedIndex = 0; // 현재 선택된 탭 인덱스

  // 탭 목록 (탭 파일이 모두 존재하는지 확인해야 합니다.)
  final List<Widget> _tabs = [
    const HomeTab(),
    const SearchTab(),
    const NearbyTab(),
    const FavoriteTab(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // 현재 선택된 탭의 내용만 표시
      body: _tabs[_selectedIndex],

      // 하단 탭 바 (BottomNavigationBar)
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home_outlined),
            activeIcon: Icon(Icons.home),
            label: '홈',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.search_outlined),
            activeIcon: Icon(Icons.search),
            label: '검색',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.near_me_outlined),
            activeIcon: Icon(Icons.near_me),
            label: '주변',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.star_outline),
            activeIcon: Icon(Icons.star),
            label: '즐겨찾기',
          ),
        ],
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
      ),
    );
  }
}