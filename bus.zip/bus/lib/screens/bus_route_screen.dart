import 'package:flutter/material.dart';
// ⚠️ [수정!] 프로젝트 이름('bus') 확인
import 'package:bus/models/bus_route_stop.dart';
import 'package:bus/models/bus_location.dart'; // ⭐️ [NEW] 버스 위치 모델 import
import 'package:bus/services/bus_api_service.dart';

class BusRouteScreen extends StatefulWidget {
  final String routeId;
  final String routeName;

  const BusRouteScreen({
    Key? key,
    required this.routeId,
    required this.routeName,
  }) : super(key: key);

  @override
  State<BusRouteScreen> createState() => _BusRouteScreenState();
}

class _BusRouteScreenState extends State<BusRouteScreen> {
  final BusApiService _apiService = BusApiService();

  // ⭐️ [수정!] 2개의 API 호출을 관리
  late Future<List<BusRouteStop>> _routeFuture; // (API 1: 정류소 목록)
  late Future<List<BusLocation>> _locationFuture; // (API 2: 버스 위치)

  // ⭐️ [NEW] 2개의 API를 '동시에' 실행할 Future
  late Future<List<dynamic>> _dataFuture;

  @override
  void initState() {
    super.initState();
    // ⭐️ [수정!] 두 API를 호출하고 Future.wait로 묶음
    _loadData();
  }

  void _loadData() {
    // 1. 각 API를 호출
    _routeFuture = _apiService.getBusRoute(widget.routeId);
    _locationFuture = _apiService.getBusLocations(widget.routeId);

    // 2. Future.wait로 두 API가 모두 완료되기를 기다림
    setState(() {
      _dataFuture = Future.wait([_routeFuture, _locationFuture]);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('${widget.routeName}번 버스 노선'),
        actions: [
          // ⭐️ [NEW] 이 화면에서도 새로고침 기능 추가
          IconButton(
            icon: const Icon(Icons.cached, color: Colors.white),
            onPressed: _loadData, // ⭐️ 두 API를 다시 호출
            tooltip: '실시간 위치 새로고침',
          ),
        ],
      ),
      // ⭐️ [수정!] FutureBuilder가 2개의 결과를 기다리도록 변경
      body: FutureBuilder<List<dynamic>>(
        future: _dataFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            // (403 에러가 뜬다면 API 신청/적용이 아직 안 된 것)
            return Center(child: Text('정보 로딩 실패: ${snapshot.error}'));
          }
          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text('노선 정보가 없습니다.'));
          }

          // --- ⭐️ 데이터 병합 (Merge) ⭐️ ---
          // 1. (API 1 결과) 모든 정류소 목록
          final List<BusRouteStop> allStops = snapshot.data![0];

          // 2. (API 2 결과) 실시간 버스 위치 목록
          final List<BusLocation> busLocations = snapshot.data![1];

          // 3. (데이터 가공) 버스가 있는 정류소 ID만 Set(집합)으로 만듦 (빠른 비교용)
          final Set<String> busLocationIds =
          busLocations.map((bus) => bus.stationId).toSet();
          // --- ⭐️ 데이터 병합 끝 ⭐️ ---

          // (성공: 노선 목록 표시)
          return ListView.builder(
            padding: const EdgeInsets.symmetric(vertical: 16),
            itemCount: allStops.length,
            itemBuilder: (context, index) {
              final stop = allStops[index];
              final isTurnPoint = stop.isTurnPoint;

              // ⭐️ [핵심!] 현재 정류소(stop)에 버스(bus)가 있는지 확인
              final bool isBusHere = busLocationIds.contains(stop.stationId);

              final Color iconColor = isTurnPoint ? Colors.red : Theme.of(context).primaryColor;

              return IntrinsicHeight(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // --- 1. 왼쪽 (타임라인 그래픽) ---
                    Container(
                      width: 40,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            width: 2,
                            height: 12,
                            color: index == 0 ? Colors.transparent : Colors.grey[300],
                          ),
                          CircleAvatar(
                            radius: isTurnPoint ? 8 : 6,
                            backgroundColor: iconColor,
                          ),
                          Expanded(
                            child: Container(
                              width: 2,
                              color: index == allStops.length - 1 ? Colors.transparent : Colors.grey[300],
                            ),
                          ),
                        ],
                      ),
                    ),

                    // --- 2. 오른쪽 (정류소 정보) ---
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.only(top: 8.0, bottom: 20.0, left: 8.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              stop.stationName,
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: isTurnPoint ? FontWeight.bold : FontWeight.normal,
                                color: isTurnPoint ? Colors.red : Colors.black87,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              '정류소 ID: ${stop.stationId}',
                              style: TextStyle(color: Colors.grey[600], fontSize: 13),
                            ),
                          ],
                        ),
                      ),
                    ),

                    // ⭐️ [NEW] 3. 실시간 버스 아이콘
                    if (isBusHere)
                      Padding(
                        padding: const EdgeInsets.only(right: 16.0, top: 8.0),
                        child: Icon(
                          Icons.directions_bus,
                          color: Colors.green, // ⭐️ 실시간 버스 색상
                          size: 28,
                        ),
                      ),
                    // ⭐️ [NEW] 반환점 아이콘 (버스가 없을 때만 표시)
                    if (isTurnPoint && !isBusHere)
                      Padding(
                        padding: const EdgeInsets.only(right: 16.0, top: 8.0),
                        child: Icon(Icons.sync, color: Colors.red, size: 24),
                      ),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }
}