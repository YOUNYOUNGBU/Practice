import 'package:flutter/material.dart';
// import 'dart:convert'; // ⚠️ [수정] jsonEncode를 사용하지 않으므로 제거
// ⚠️ [수정!] 프로젝트 이름('bus') 확인
import 'package:bus/models/bus_arrival_info.dart';
import 'package:bus/models/bus_station.dart';
import 'package:bus/services/bus_api_service.dart';
import 'package:bus/screens/bus_arrival_detail_screen.dart'; // (상세보기 화면)


// 1. 카드 자체가 'Stateful' 위젯이 되어 스스로 API를 호출합니다.
class FavoriteStationCard extends StatefulWidget {
  final BusStation station;
  final VoidCallback onRemove; // 삭제 버튼이 눌렸을 때 부모에게 알림

  const FavoriteStationCard({
    Key? key,
    required this.station,
    required this.onRemove,
  }) : super(key: key);

  @override
  State<FavoriteStationCard> createState() => _FavoriteStationCardState();
}

class _FavoriteStationCardState extends State<FavoriteStationCard> {
  final BusApiService _apiService = BusApiService();
  late Future<List<BusArrivalInfo>> _arrivalInfoFuture;

  @override
  void initState() {
    super.initState();
    // 2. 이 카드가 생성될 때(initState) API 호출을 시작
    _arrivalInfoFuture = _apiService.fetchBusArrival(widget.station.stationId);
  }

  // (새로고침 함수)
  void _refreshArrivalInfo() {
    setState(() {
      // 3. API 호출을 다시 해서 Future를 갱신
      _arrivalInfoFuture = _apiService.fetchBusArrival(widget.station.stationId);
    });
  }

  // (상세보기 화면으로 이동)
  void _navigateToDetail() {
    Navigator.push(
      context,
      MaterialPageRoute(
        // 4. 이미 만든 '상세보기' 화면을 재사용
        builder: (context) => BusArrivalDetailScreen(station: widget.station),
      ),
    ).then((_) => _refreshArrivalInfo()); // ⭐️ 돌아왔을 때 새로고침
  }

  // ⭐️ [NEW] 에러 또는 데이터 없음 뷰
  Widget _buildErrorView(String message) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 20.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.info_outline, color: Colors.grey[500], size: 18),
            const SizedBox(width: 8),
            Text(message, style: TextStyle(color: Colors.grey[600], fontSize: 15)),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Card( // (테마는 main.dart의 CardTheme을 따름)
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // --- 1. 카드 헤더 (정류소 이름, 삭제 버튼) ---
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Text(
                    widget.station.stationName, // "수원역.AK플라자"
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.cancel, color: Colors.redAccent, size: 24),
                  onPressed: widget.onRemove, // 부모가 알려준 '삭제' 함수 실행
                  tooltip: '즐겨찾기에서 삭제',
                ),
              ],
            ),
            Text(
              'ID: ${widget.station.stationId} | 번호: ${widget.station.mobileNo}',
              style: TextStyle(color: Colors.grey[600], fontSize: 13),
            ),
            const Divider(height: 24), // --- 구분선 ---

            // --- 2. 버스 도착 정보 (FutureBuilder) ---
            FutureBuilder<List<BusArrivalInfo>>(
              future: _arrivalInfoFuture,
              builder: (context, snapshot) {
                // (로딩 중)
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(
                    child: Padding(
                      padding: EdgeInsets.symmetric(vertical: 20.0),
                      child: CircularProgressIndicator(),
                    ),
                  );
                }
                // (에러)
                if (snapshot.hasError) {
                  return _buildErrorView('정보 로딩 실패');
                }
                // (데이터 없음)
                if (!snapshot.hasData || snapshot.data!.isEmpty) {
                  return _buildErrorView('도착 예정 버스가 없습니다');
                }

                // (성공)
                final arrivals = snapshot.data!;

                // ⭐️ 이미지처럼 최대 3개만 미리보기로 보여줌
                int displayCount = arrivals.length > 3 ? 3 : arrivals.length;

                return Column(
                  children: [
                    // (버스 목록)
                    for (int i = 0; i < displayCount; i++)
                      _buildArrivalRow(arrivals[i]),

                    // (더보기 / 새로고침 버튼)
                    const SizedBox(height: 12),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        TextButton.icon(
                          icon: const Icon(Icons.read_more, size: 18),
                          label: Text('전체 버스 보기 (${arrivals.length}대)'),
                          onPressed: _navigateToDetail, // ⭐️ 상세보기 화면으로
                        ),
                        TextButton.icon(
                          icon: const Icon(Icons.refresh, size: 18),
                          label: const Text('새로고침'),
                          onPressed: _refreshArrivalInfo,
                        ),
                      ],
                    )
                  ],
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  // (UI 빌더) 버스 한 줄을 그리는 함수
  Widget _buildArrivalRow(BusArrivalInfo arrival) {
    // ⭐️ [수정] predictTime 또는 arrivalInfo를 사용하도록 변경
    final String timeText = arrival.predictTime != null
        ? '${arrival.predictTime}분 후'
        : arrival.arrivalInfo ?? '정보 없음';

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          // (버스 번호)
          Text(
            // ⭐️ [수정!] Null Check 적용
            arrival.routeName ?? 'N/A',
            style: const TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 17,
              color: Colors.indigo, // ⭐️ 포인트 컬러
            ),
          ),
          // (도착 시간)
          Text(
            timeText, // ⭐️ [수정] timeText 사용
            style: const TextStyle(
              color: Colors.deepOrange,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          // (차량 번호 - 이미지의 '여유'/'보통' 자리)
          SizedBox(
            width: 100, // (공간 확보)
            child: Text(
              // ⭐️ [수정!] Null Check 적용
              arrival.plateNo ?? '차량 정보 없음',
              style: TextStyle(color: Colors.grey[600], fontSize: 13),
              textAlign: TextAlign.right,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }
}